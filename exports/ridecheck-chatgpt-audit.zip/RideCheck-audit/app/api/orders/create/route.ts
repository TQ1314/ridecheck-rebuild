// app/api/orders/create/route.ts
import { NextRequest, NextResponse } from "next/server";
import { createRouteHandlerSupabaseClient } from "@/lib/supabase/route-handler";
import { supabaseAdmin } from "@/lib/supabase/admin";
import { getPrice, type PackageType, type BookingType } from "@/lib/utils/pricing";
import { classifyVehicle } from "@/lib/vehicleClassification.server";
import { resolveCounty, checkPilotPhase, PILOT_CONFIG } from "@/lib/geo/resolveCounty";
import { buildOptionalOrderFields, createOrderSchema } from "./contract";
import { notifyNewOrderRequest } from "@/lib/notifications/order-created-ops";
import { buildFacebookHandoffEvents, isFacebookMarketplaceListing, FACEBOOK_SOURCE } from "@/lib/seller-contact/facebook-marketplace";
import { currentIntakeSession } from "@/lib/booking-intake/session";
import { writeAuditLog } from "@/lib/rbac";

export const runtime = "nodejs";

function safeString(v: unknown, fallback = "") {
  return typeof v === "string" ? v : fallback;
}

function safeNullableString(v: unknown): string | null {
  return typeof v === "string" ? v : null;
}

export const dynamic = "force-dynamic";

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const parsed = createOrderSchema.safeParse(body);

    if (!parsed.success) {
      return NextResponse.json(
        { error: "Validation failed", details: parsed.error.flatten() },
        { status: 400 }
      );
    }

    const data = parsed.data;
    const facebookMarketplace = isFacebookMarketplaceListing(data.listing_url, data.platform_source);

    if (PILOT_CONFIG.enabled) {
      const county = resolveCounty(data.service_zip);

      if (county === "unknown") {
        return NextResponse.json(
          {
            error: "service_unavailable",
            message: "RideCheck is currently available in Lake County and McHenry County, IL. We're expanding soon!",
            allowed_counties: ["lake", "mchenry"],
            state: "IL",
          },
          { status: 409 }
        );
      }

      let totalOrders = 0;
      const countsByCounty: Record<string, number> = {};

      try {
        const { count: totalCount } = await supabaseAdmin
          .from("orders")
          .select("*", { count: "exact", head: true })
          .neq("status", "cancelled");

        totalOrders = totalCount || 0;

        const { data: countRows } = await supabaseAdmin
          .from("orders")
          .select("service_county")
          .neq("status", "cancelled")
          .not("service_county", "is", null);

        if (countRows) {
          for (const row of countRows) {
            const c = row.service_county as string;
            countsByCounty[c] = (countsByCounty[c] || 0) + 1;
          }
        }
      } catch {
        // service_county column may not exist yet — proceed with defaults
      }

      const phaseResult = checkPilotPhase(county, totalOrders, countsByCounty);

      if (!phaseResult.allowed) {
        const messages: Record<string, string> = {
          pilot_capacity_reached: "RideCheck pilot has reached capacity. Join the waitlist for updates!",
          county_locked: `RideCheck is not yet available in ${county} county. We're rolling out in phases: Lake → McHenry → Cook.`,
          county_cap_reached: `RideCheck has reached capacity in ${county} county for now. Check back soon!`,
        };

        return NextResponse.json(
          {
            error: phaseResult.error || "service_unavailable",
            message: messages[phaseResult.error || ""] || "Service unavailable in this area.",
            allowed_counties: phaseResult.allowedCounties,
            current_phase: phaseResult.currentPhase,
            state: "IL",
            ...(phaseResult.unlocks_after_total_orders !== undefined && {
              unlocks_after_total_orders: phaseResult.unlocks_after_total_orders,
            }),
          },
          { status: 409 }
        );
      }
    }

    const supabase = createRouteHandlerSupabaseClient();
    const {
      data: { session },
    } = await supabase.auth.getSession();

    const buyer_email = safeString(data.buyer_email_input || session?.user?.email, "redacted-contact-3@example.invalid");
    const buyer_phone = data.buyer_phone;
    const customer_id = session?.user?.id ?? null;

    const classification = classifyVehicle({
      make: data.vehicle_make,
      model: [data.vehicle_model, data.vehicle_trim].filter(Boolean).join(" "),
      year: data.vehicle_year,
      mileage: data.vehicle_mileage ?? null,
      askingPrice: data.vehicle_price ?? null,
      fuelType: data.vehicle_fuel_type ?? null,
      collector: data.vehicle_collector ?? false,
    });

    const serverPackage = classification.packageTier;
    const { basePrice, finalPrice, discountAmount } = getPrice(
      classification.packageTier as PackageType,
      data.booking_type as BookingType
    );

    const tracking_token = crypto.randomUUID();
    const payment_link_token = crypto.randomUUID();

    const insertPayload: Record<string, any> = {
      buyer_email,
      buyer_phone,
      ...(customer_id && { customer_id }),

      booking_type: data.booking_type,
      status: "submitted",
      payment_status: "unpaid",
      ops_status: "pending_payment",

      vehicle_year: data.vehicle_year,
      vehicle_make: data.vehicle_make,
      vehicle_model: data.vehicle_model,
      vehicle_location: data.vehicle_location,
      vehicle_description: data.vehicle_fuel_type || data.vehicle_collector
        ? [data.vehicle_description, data.vehicle_fuel_type && `Fuel type: ${data.vehicle_fuel_type}`, data.vehicle_collector && "Collector vehicle: buyer indicated"].filter(Boolean).join("\n")
        : data.vehicle_description ?? null,

      listing_url: data.listing_url ?? null,
      listing_source: data.listing_source ?? "online_marketplace",
      platform_source: facebookMarketplace ? FACEBOOK_SOURCE : data.platform_source ?? null,
      vehicle_seen_location: data.vehicle_seen_location ?? null,
      seller_name: data.seller_name ?? null,
      seller_phone: data.seller_phone ?? null,
      seller_type: data.seller_type ?? "private_party",

      package: serverPackage,
      preferred_date: data.preferred_date ?? null,

      base_price: basePrice,
      final_price: finalPrice,
      discount_amount: discountAmount,

      tracking_token,
      payment_link_token,
    };

    // These columns are present in the canonical upgrade migration, but older
    // installations may still be running the base schema. Probe individually
    // so manual booking remains compatible while upgraded installations retain
    // the buyer-arranged handoff and intake metadata.
    const optionalOrderColumns = [
      "booking_method", "preferred_language", "inspection_address",
      "inspection_time_window", "notes_to_inspector", "vehicle_trim",
      "listing_platform", "listing_claimed_vin", "intake_provenance",
      ...(facebookMarketplace ? ["seller_email", "seller_available_date", "seller_available_time"] : []),
    ] as const;
    const optionalColumnResults = await Promise.all(optionalOrderColumns.map(async (column) => {
      const { error } = await supabaseAdmin.from("orders").select(column).limit(0);
      return [column, !error] as const;
    }));
    const availableOptionalColumns = new Set(
      optionalColumnResults.filter(([, available]) => available).map(([column]) => column),
    );
    const optionalFields = buildOptionalOrderFields(data, availableOptionalColumns);
    if (optionalFields.error) {
      console.error("[Order Create] optional intake storage unavailable", optionalFields.error);
      return NextResponse.json({
        error: optionalFields.error.code,
        message: optionalFields.error.message,
        ...(optionalFields.error.missing_fields
          ? { missing_fields: optionalFields.error.missing_fields }
          : {}),
      }, { status: 503 });
    }
    Object.assign(insertPayload, optionalFields.fields);
    if (facebookMarketplace) {
      const { error: eventStorageError } = await supabaseAdmin
        .from("order_events").select("order_id,event_type,details,actor_id,actor_email,is_internal").limit(0);
      if (eventStorageError) {
        return NextResponse.json({ error: "seller_consent_storage_unavailable", message: "Seller agreement could not be saved. Please try again later." }, { status: 503 });
      }
    }

    try {
      const { error: colErr } = await supabaseAdmin
        .from("orders")
        .select("classification_reason")
        .limit(0);
      if (!colErr) {
        if (classification.modifier) {
          insertPayload.classification_modifier = classification.modifier;
        }
        if (classification.classificationReason) {
          insertPayload.classification_reason = classification.classificationReason;
        }
        if (data.vehicle_mileage) {
          insertPayload.vehicle_mileage = data.vehicle_mileage;
        }
        if (data.vehicle_price) {
          insertPayload.vehicle_price = data.vehicle_price;
        }
      }
    } catch {
      // classification columns not yet migrated (010) — skip storing them
    }

    try {
      const { error: svcErr } = await supabaseAdmin
        .from("orders")
        .select("service_zip")
        .limit(0);
      if (!svcErr) {
        insertPayload.service_zip = data.service_zip;
        insertPayload.service_county = resolveCounty(data.service_zip);
        insertPayload.service_state = "IL";
      }
    } catch {
      // service area columns not yet migrated (007) — skip storing them
    }

    const { data: order, error } = await supabaseAdmin
      .from("orders")
      .insert(insertPayload)
      .select("id, order_number, created_at")
      .single();

    if (error) {
      console.error("[Order Create Error]", error);
      return NextResponse.json(
        {
          error: "Failed to create order",
          debug: {
            code: safeNullableString((error as any)?.code),
            message: safeNullableString((error as any)?.message),
            details: safeNullableString((error as any)?.details),
            hint: safeNullableString((error as any)?.hint),
          },
        },
        { status: 500 }
      );
    }

    // Buyer consent is evidence only. Never set seller_status,
    // seller_contact_status, confirmed scheduling, or payment fields from it.
    let facebookAuditWarning = false;
    if (facebookMarketplace && data.facebook_contact) {
      const now = new Date().toISOString();
      const hasDetails = !!(data.seller_name || data.seller_phone || data.seller_email ||
        data.inspection_address || data.seller_available_date || data.seller_available_time);
      const rows = buildFacebookHandoffEvents(data.facebook_contact, now, hasDetails).map((event) => ({
        order_id: order.id,
        actor_id: customer_id,
        actor_email: buyer_email,
        ...event,
        is_internal: true,
      }));
      const { error: eventError } = await supabaseAdmin.from("order_events").insert(rows);
      if (eventError) {
        facebookAuditWarning = true;
        console.error("[Facebook handoff] order created but audit snapshot failed", { orderId: order.id, error: eventError });
      }
      try {
        await writeAuditLog({
          actorId: customer_id, actorEmail: buyer_email, actorRole: customer_id ? "buyer" : "guest",
          action: "facebook_seller_contact_handoff", resourceId: order.id,
          metadata: { intake_session_id: currentIntakeSession(), source: FACEBOOK_SOURCE, audit_snapshot_saved: !eventError },
        });
      } catch (auditError) {
        console.error("[Facebook handoff] correlation failed", { orderId: order.id, auditError });
      }
    }

    // An unpaid request is visible to Ops for recovery, never for fulfillment.
    // This alert is informational and must not block payment or change its state.
    try {
      await notifyNewOrderRequest({
        id: order.id,
        created_at: order.created_at,
        buyer_email,
        buyer_phone,
        vehicle_year: data.vehicle_year,
        vehicle_make: data.vehicle_make,
        vehicle_model: data.vehicle_model,
        package: serverPackage,
        final_price: finalPrice,
        booking_type: data.booking_type,
        seller_name: data.seller_name,
        seller_phone: data.seller_phone,
        seller_type: data.seller_type,
        inspection_address: data.inspection_address,
        vehicle_location: data.vehicle_location,
        preferred_date: data.preferred_date,
      });
    } catch (alertError) {
      console.error("[order created ops] notification failed", { orderId: order.id, error: alertError });
    }

    // Phase 3: stamp profile_type on authenticated buyer (best-effort, additive only)
    if (customer_id) {
      try {
        await supabaseAdmin
          .from("profiles")
          .update({
            profile_type: "customer",
            origin_type: "order_checkout",
            origin_id: order.id,
          })
          .eq("id", customer_id)
          .is("origin_id", null); // only set origin on their first order
      } catch (profileStampErr) {
        console.error("[Order Create] Profile stamp error:", profileStampErr);
      }
    }

    const track_url = `/track/${order.id}?t=${tracking_token}`;

    const appUrl = process.env.NEXT_PUBLIC_APP_URL || "";
    const payUrl = `${appUrl}/pay/${order.id}?t=${payment_link_token}`;
    const vehicleLabel = `${data.vehicle_year} ${data.vehicle_make} ${data.vehicle_model}`;

    let paymentChannel: string | null = null;
    try {
      if (buyer_phone) {
        const { sendSMS } = await import("@/lib/notifications/sms");
        const smsResult = await sendSMS({
          to: buyer_phone,
          body: `RideCheck: Confirm your inspection for ${vehicleLabel}. Pay securely here: ${payUrl}`,
          event: "order.payment-link",
          template: "order-payment-link-sms",
          orderId: order.id,
        });
        if (smsResult.success) {
          paymentChannel = "sms";
        }
      }

      if (paymentChannel) {
        await supabaseAdmin
          .from("orders")
          .update({
            payment_link_sent_to: paymentChannel === "sms" ? buyer_phone : buyer_email,
            payment_link_sent_channel: paymentChannel,
            payment_link_sent_at: new Date().toISOString(),
          })
          .eq("id", order.id);
      }
    } catch (linkErr) {
      console.error("[Payment Link Send Error]", linkErr);
    }

    try {
      if (buyer_email && buyer_email !== "redacted-contact-3@example.invalid") {
        const { orderConfirmationHtml } = await import("@/lib/email/templates/order-confirmation");
        const { sendEmail } = await import("@/lib/notifications/email");
        const pkgLabel = (serverPackage || "standard").charAt(0).toUpperCase() + (serverPackage || "standard").slice(1);
        const confirmHtml = orderConfirmationHtml({
          orderNumber: order.order_number,
          customerName: buyer_email.split("@")[0],
          vehicleYear: data.vehicle_year,
          vehicleMake: data.vehicle_make,
          vehicleModel: data.vehicle_model,
          packageName: pkgLabel,
          finalPrice: String(finalPrice),
          bookingType: data.booking_type,
          listingSource: data.listing_source ?? "online_marketplace",
          facebookMarketplace,
          trackUrl: track_url,
          payUrl,
        });
        const confirmationResult = await sendEmail({
          to: buyer_email,
          subject: `Your RideCheck request is pending payment — ${vehicleLabel}`,
          html: confirmHtml,
          event: "order.confirmation",
          template: "order-confirmation",
          orderId: order.id,
        });
        if (confirmationResult.success && !paymentChannel) {
          paymentChannel = "email";
          await supabaseAdmin.from("orders").update({
            payment_link_sent_to: buyer_email,
            payment_link_sent_channel: "email",
            payment_link_sent_at: new Date().toISOString(),
          }).eq("id", order.id);
        } else if (!confirmationResult.success) {
          console.error("[Order Confirmation Email] Provider rejected pending request email", { orderId: order.id });
        }
      }
    } catch (confirmErr) {
      console.error("[Order Confirmation Email Error]", confirmErr);
    }

    const isDebug =
      process.env.DEBUG_PAYMENT_LINKS === "true" &&
      process.env.NODE_ENV !== "production";

    const response: Record<string, any> = {
      order,
      pricing: {
        basePrice,
        finalPrice,
        discountAmount,
      },
      track_url,
      payment_channel: paymentChannel,
      ...(facebookAuditWarning ? { facebook_audit_warning: "Your request was saved, but the buyer-reported seller agreement could not be added to the timeline. Tell Ops before seller coordination." } : {}),
    };

    if (isDebug) {
      response.debug = { payment_url: payUrl, channel: paymentChannel || "none" };
    }

    return NextResponse.json(response);
  } catch (err: any) {
    console.error("[Order Create Error]", err);
    return NextResponse.json(
      { error: err?.message || "Internal server error" },
      { status: 500 }
    );
  }
}