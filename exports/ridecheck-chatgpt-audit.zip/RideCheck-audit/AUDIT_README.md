# RideCheck source audit

This is a sanitized, source-only snapshot for an independent ChatGPT audit.
Start with package.json, replit.md, the Next.js app routes, middleware.ts,
lib/supabase, lib/rbac.ts, lib/payment, and supabase/migrations.
Map active entrypoints before assuming legacy client/server files are deployed.

Audit without changing code. Prioritize:
1. Authentication, role checks, tenant/order ownership, tracking-token access.
2. Payment-first gates, Stripe webhook validation, payment amounts/idempotency.
3. Booking contracts, seller contact/consent, coordination, inbound webhooks.
4. Inspector access, uploads, storage policies, evidence/PII retention.
5. Assignment/compensation, inspection completion, QA and report delivery.
6. Database constraints/RLS, secrets exposure, dependencies and failure handling.

For each finding: severity, path and line(s), concrete evidence, affected flow,
likely impact, suggested minimal fix, and confidence. Separate confirmed issues
from questions that require runtime or live-schema verification. Do not invent
findings from redacted placeholder values or treat fixtures as live customers.
Do not deploy, execute migrations, create bookings, send communications, or make
payments. Do not request production credentials. Use static analysis and mocked
tests only. No secrets or runtime environment values are supplied.

EXCLUSIONS
No .env files, .replit configuration, Git history/remotes, agent memory/profiles,
attached_assets, private uploads, logs, caches, dependency directories, build
outputs, databases/dumps, spreadsheets, PDFs, public photos/video, or live data.
Original files in the Replit project were not modified.

SANITIZATION
High-confidence key/token/private-key/credential-URL patterns and literal secret
assignments were masked. Non-example email addresses, non-555 formatted/quoted
phone numbers, project URLs, and VIN-like values outside test fixtures were
masked with consistent replacements. Public business email addresses may also
be masked. Synthetic example-domain contacts and VIN fixtures remain in tests.
See SANITIZATION_REPORT.json for paths and counts; it contains no original values.
Automatic scanning is not a guarantee that every possible sensitive value is
detectable. This archive deliberately excludes uploaded documents and data.
Redactions may affect fixtures or sample configuration; it is not a turnkey
deployment bundle. Images and media referenced by the code are not included.

ENVIRONMENT_VARIABLE_NAMES.txt lists code-referenced variable names only,
without values. EXPORT_MANIFEST.json hashes the SANITIZED files, not originals.
The included feature report describes previous implementation verification, not
a new audit performed by this export task.
