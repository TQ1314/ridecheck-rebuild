import { NextRequest, NextResponse } from "next/server";
import { createRouteHandlerSupabaseClient } from "@/lib/supabase/route-handler";
import { supabaseAdmin } from "@/lib/supabase/admin";
import { canSendPayment, type Role } from "@/lib/utils/roles";
import { getStripe } from "@/lib/stripe/server";
import { sendEmail } from "@/lib/email/resend";
import { paymentRequestHtml } from "@/lib/email/templates/payment-request";

export const dynamic = "force-dynamic";

export async function POST(
  req: NextRequest,
  { params }: { params: { orderId: string } },
) {
  try {
    const supabase = createRouteHandlerSupabaseClient();
    const {
      data: { session },
    } = await supabase.auth.getSession();

    if (!session) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { data: profile } = await supabaseAdmin
      .from("profiles")
      .select("role")
      .eq("id", session.user.id)
      .maybeSingle();

    if (!profile || !canSendPayment(profile.role as Role)) {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 });
    }

    const { data: order } = await supabaseAdmin
      .from("orders")
      .select("*")
      .eq("id", params.orderId)
      .single();

    if (!order) {
      return NextResponse.json({ error: "Order not found" }, { status: 404 });
    }

    if (order.payment_status !== "not_requested") {
      return NextResponse.json(
        { error: "Payment already requested or paid" },
        { status: 400 },
      );
    }
    const priceCents = Math.round(Number(order.final_price) * 100);
    if (!Number.isSafeInteger(priceCents) || priceCents <= 0) {
      return NextResponse.json({ error: "Order price is invalid; payment request not created" }, { status: 409 });
    }

    const stripe = getStripe();
    let paymentUrl = "";

    if (stripe) {
      const appUrl = process.env.NEXT_PUBLIC_APP_URL || "";
      const checkoutSession = await stripe.checkout.sessions.create({
        mode: "payment",
        line_items: [
          {
            price_data: {
              currency: "usd",
              product_data: {
                name: `RideCheck ${order.package.charAt(0).toUpperCase() + order.package.slice(1)} Assessment`,
                description: `${order.vehicle_year} ${order.vehicle_make} ${order.vehicle_model}`,
              },
              unit_amount: priceCents,
            },
            quantity: 1,
          },
        ],
        metadata: {
          order_id: params.orderId,
          customer_email: order.buyer_email || order.customer_email || "",
          ...(order.payment_link_token && { payment_link_token: order.payment_link_token }),
        },
        payment_intent_data: {
          metadata: {
            order_id: params.orderId,
            ...(order.payment_link_token && { payment_link_token: order.payment_link_token }),
          },
        },
        success_url: `${appUrl}/orders/${params.orderId}?payment=success`,
        cancel_url: `${appUrl}/orders/${params.orderId}?payment=cancelled`,
      });
      paymentUrl = checkoutSession.url || "";

      const { data: linked, error: linkError } = await supabaseAdmin
        .from("orders")
        .update({
          payment_status: "requested",
          stripe_session_id: checkoutSession.id,
          stripe_checkout_session_id: checkoutSession.id,
          status: "payment_requested",
          updated_at: new Date().toISOString(),
        })
        .eq("id", params.orderId)
        .eq("payment_status", "not_requested")
        .select("id");
      if (linkError || !linked?.length) {
        console.error("[Send Payment] Checkout created but order linkage failed", { orderId: params.orderId, error: linkError });
        return NextResponse.json({ error: "Payment session could not be linked; contact support" }, { status: 503 });
      }
    } else {
      await supabaseAdmin
        .from("orders")
        .update({
          payment_status: "requested",
          status: "payment_requested",
          updated_at: new Date().toISOString(),
        })
        .eq("id", params.orderId);
    }

    await supabaseAdmin.from("activity_log").insert({
      user_id: session.user.id,
      order_id: params.orderId,
      action: "payment_requested",
      details: { payment_url: paymentUrl },
    });

    if (order.customer_email && paymentUrl) {
      sendEmail({
        to: order.customer_email,
        subject: `Payment Required - Order ${params.orderId}`,
        html: paymentRequestHtml({
          orderId: params.orderId,
          customerName: order.customer_name,
          finalPrice: String(order.final_price),
          paymentUrl,
        }),
      }).catch(console.error);
    }

    return NextResponse.json({ success: true, payment_url: paymentUrl });
  } catch (err: any) {
    console.error("[Send Payment Error]", err);
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
