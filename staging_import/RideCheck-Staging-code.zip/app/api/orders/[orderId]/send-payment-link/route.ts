import { NextRequest, NextResponse } from "next/server";
import { supabaseAdmin } from "@/lib/supabase/admin";
import { sendSMS } from "@/lib/notifications/sms";
import { sendEmail } from "@/lib/notifications/email";

export const runtime = "nodejs";

export const dynamic = "force-dynamic";

export async function POST(
  req: NextRequest,
  { params }: { params: { orderId: string } }
) {
  try {
    const { data: order, error } = await supabaseAdmin
      .from("orders")
      .select("id, buyer_phone, buyer_email, payment_status, vehicle_year, vehicle_make, vehicle_model, package, booking_type, final_price, payment_link_token")
      .eq("id", params.orderId)
      .maybeSingle();

    if (error || !order) {
      return NextResponse.json({ error: "Order not found" }, { status: 404 });
    }

    if (order.payment_status === "paid") {
      return NextResponse.json({ error: "Order already paid" }, { status: 400 });
    }

    const phone = order.buyer_phone;
    const email = order.buyer_email;

    if (!phone && !email) {
      return NextResponse.json({ error: "No contact method available" }, { status: 400 });
    }

    const isNewToken = !order.payment_link_token;
    const token = order.payment_link_token || crypto.randomUUID();
    const appUrl = process.env.NEXT_PUBLIC_APP_URL || "";
    const payUrl = `${appUrl}/pay/${order.id}?t=${token}`;
    const vehicleLabel = `${order.vehicle_year} ${order.vehicle_make} ${order.vehicle_model}`;

    let channel: "sms" | "email" | null = null;
    let sentTo: string | null = null;

    if (phone) {
      const smsResult = await sendSMS({
        to: phone,
        body: `RideCheck: Confirm your inspection for ${vehicleLabel}. Pay securely here: ${payUrl}`,
      });
      if (smsResult.success) {
        channel = "sms";
        sentTo = phone;
      } else if (email) {
        const price = Number(order.final_price || 0);
        const emailResult = await sendEmail({
          to: email,
          subject: "RideCheck payment link for your inspection",
          html: `<p>Hi! Your RideCheck inspection for <strong>${vehicleLabel}</strong> is ready for payment.</p><p>Price: <strong>$${price}</strong></p><p><a href="${payUrl}" style="display:inline-block;padding:12px 24px;background:#059669;color:#fff;text-decoration:none;border-radius:6px;font-weight:bold;">Pay Now</a></p><p>Or copy this link: ${payUrl}</p>`,
        });
        if (emailResult.success) {
          channel = "email";
          sentTo = email;
        }
      }
    } else if (email) {
      const price = Number(order.final_price || 0);
      const emailResult = await sendEmail({
        to: email,
        subject: "RideCheck payment link for your inspection",
        html: `<p>Hi! Your RideCheck inspection for <strong>${vehicleLabel}</strong> is ready for payment.</p><p>Price: <strong>$${price}</strong></p><p><a href="${payUrl}" style="display:inline-block;padding:12px 24px;background:#059669;color:#fff;text-decoration:none;border-radius:6px;font-weight:bold;">Pay Now</a></p><p>Or copy this link: ${payUrl}</p>`,
      });
      if (emailResult.success) {
        channel = "email";
        sentTo = email;
      }
    }

    if (!channel || !sentTo) {
      return NextResponse.json({ error: "Failed to send payment link via SMS or email" }, { status: 502 });
    }

    const updatePayload: Record<string, any> = {
      payment_link_sent_to: sentTo,
      payment_link_sent_channel: channel,
      payment_link_sent_at: new Date().toISOString(),
    };

    if (isNewToken) {
      updatePayload.payment_link_token = token;
    }

    await supabaseAdmin
      .from("orders")
      .update(updatePayload)
      .eq("id", params.orderId);

    const isDebug =
      process.env.DEBUG_PAYMENT_LINKS === "true" &&
      process.env.NODE_ENV !== "production";

    if (isDebug) {
      return NextResponse.json({
        ok: true,
        channel,
        debug: { payment_url: payUrl, channel },
      });
    }

    return NextResponse.json({ ok: true, channel });
  } catch (err: any) {
    console.error("[Send Payment Link Error]", err);
    return NextResponse.json({ error: err?.message || "Internal error" }, { status: 500 });
  }
}
