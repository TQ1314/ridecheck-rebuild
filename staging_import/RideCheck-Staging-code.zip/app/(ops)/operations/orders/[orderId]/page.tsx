"use client";

import { useEffect, useState, useCallback, useRef } from "react";
import { useParams } from "next/navigation";
import { createClient } from "@/lib/supabase/client";
import type { Order, ActivityLogEntry, Profile } from "@/types/orders";
import { OrderDetailPanel } from "@/components/orders/OrderDetailPanel";
import { SellerContactPanel } from "@/components/orders/SellerContactPanel";
import { BuyerCard } from "@/components/orders/BuyerCard";
import { RideCheckerAssignmentPanel } from "@/components/orders/RideCheckerAssignmentPanel";
import { RideCheckerCompensationPanel } from "@/components/orders/RideCheckerCompensationPanel";
import { PayPanel } from "@/components/orders/PayPanel";
import { ReportPanel } from "@/components/orders/ReportPanel";
import { RiskFlagsPanel } from "@/components/orders/RiskFlagsPanel";
import { ConnecteamPanel } from "@/components/orders/ConnecteamPanel";
import { CommunicationCenter } from "@/components/orders/CommunicationCenter";
import { SellerRefusalAnalyticsCard } from "@/components/orders/SellerRefusalAnalyticsCard";
import { JobStatusPanel } from "@/components/orders/JobStatusPanel";
import { StatusUpdateDialog } from "@/components/orders/StatusUpdateDialog";
import { AssignOpsDialog } from "@/components/orders/AssignOpsDialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  ArrowLeft,
  Send,
  ShieldCheck,
  Loader2,
  Clock,
  Lock,
  AlertTriangle,
  CheckCircle2,
  CircleDollarSign,
  FileText,
  ChevronDown,
  ChevronUp,
} from "lucide-react";
import Link from "next/link";
import { useToast } from "@/hooks/use-toast";
import { canUpdateStatus, canAssignOps, canSendPayment, type Role } from "@/lib/utils/roles";
import { packageLabel } from "@/lib/utils/format";
import { canProceedWithRideCheck } from "@/lib/payment/payment-gate";

const PACKAGE_OPTIONS = [
  { value: "standard", label: "Basic — $139" },
  { value: "plus",     label: "Plus — $169" },
  { value: "exotic",   label: "Exotic — $299" },
];

// ── Title Transfer Card ───────────────────────────────────────────────────────
function TitleTransferCard({ orderId, sellerType }: { orderId: string; sellerType?: string }) {
  const [data, setData] = useState<{
    transfer_readiness_status: string;
    risk_flags: string[];
    title_present: boolean | null;
    seller_name_on_title: string | null;
    vin_matches_title: string | null;
    open_title: string | null;
    summary: string;
    checked_at: string;
  } | null>(null);
  const [loading, setLoading] = useState(true);
  const [expanded, setExpanded] = useState(false);

  useEffect(() => {
    if (!orderId) return;
    fetch(`/api/ridechecker/orders/${orderId}/title-transfer-check`)
      .then((r) => (r.ok ? r.json() : null))
      .then((d) => { if (d?.check) setData(d.check); })
      .catch(() => {})
      .finally(() => setLoading(false));
  }, [orderId]);

  const statusConfig: Record<string, { cls: string; label: string }> = {
    ready:   { cls: "bg-emerald-100 text-emerald-700 border-emerald-200", label: "READY" },
    caution: { cls: "bg-amber-100  text-amber-700  border-amber-200",  label: "CAUTION" },
    concern: { cls: "bg-red-100    text-red-700    border-red-200",    label: "CONCERN" },
    unknown: { cls: "bg-gray-100   text-gray-600   border-gray-200",   label: "UNKNOWN" },
  };

  const sc = data ? (statusConfig[data.transfer_readiness_status] ?? statusConfig.unknown) : null;
  const showWarning = sellerType === "private_party" && !loading && !data;

  return (
    <Card data-testid="card-title-transfer">
      <CardHeader className="pb-3">
        <CardTitle className="text-sm flex items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <FileText className="h-4 w-4 text-primary" />
            Title &amp; Transfer Readiness
          </div>
          {data && (
            <button
              onClick={() => setExpanded((e) => !e)}
              className="text-muted-foreground hover:text-foreground"
              data-testid="button-toggle-title-transfer"
            >
              {expanded ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
            </button>
          )}
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        {loading && (
          <div className="flex items-center gap-2 text-xs text-muted-foreground">
            <Loader2 className="h-3.5 w-3.5 animate-spin" /> Loading…
          </div>
        )}
        {!loading && showWarning && (
          <div className="flex items-start gap-2 text-xs text-amber-700 bg-amber-50 dark:bg-amber-950/20 dark:text-amber-400 border border-amber-200 dark:border-amber-800 rounded-md px-3 py-2">
            <AlertTriangle className="h-3.5 w-3.5 shrink-0 mt-0.5" />
            <span>No title transfer check recorded. Private-party orders require this before report delivery.</span>
          </div>
        )}
        {!loading && data && sc && (
          <>
            <div className={`flex items-center gap-2 px-2.5 py-1.5 rounded border text-xs font-semibold ${sc.cls}`}>
              {sc.label === "READY" ? <CheckCircle2 className="h-3.5 w-3.5" /> : <AlertTriangle className="h-3.5 w-3.5" />}
              Transfer Readiness: {sc.label}
            </div>
            <p className="text-xs text-muted-foreground">{data.summary}</p>
            {data.risk_flags?.length > 0 && (
              <ul className="text-xs text-red-600 dark:text-red-400 space-y-0.5 pl-3 list-disc">
                {data.risk_flags.map((f: string) => <li key={f}>{f.replace(/_/g, " ")}</li>)}
              </ul>
            )}
            {expanded && (
              <div className="pt-2 border-t space-y-1 text-xs text-muted-foreground">
                <p><span className="font-medium">Title present:</span> {String(data.title_present ?? "—")}</p>
                <p><span className="font-medium">VIN matches title:</span> {data.vin_matches_title ?? "—"}</p>
                <p><span className="font-medium">Open title:</span> {data.open_title ?? "—"}</p>
                {data.seller_name_on_title && (
                  <p><span className="font-medium">Seller on title:</span> {data.seller_name_on_title}</p>
                )}
                <p className="text-[10px] text-muted-foreground/70">
                  Checked {data.checked_at ? new Date(data.checked_at).toLocaleString() : "—"}
                </p>
              </div>
            )}
          </>
        )}
        {!loading && !data && !showWarning && (
          <p className="text-xs text-muted-foreground">Not applicable for this seller type.</p>
        )}
      </CardContent>
    </Card>
  );
}

function formatAge(isoDate: string | undefined | null): { label: string; color: string } | null {
  if (!isoDate) return null;
  const ms = Date.now() - new Date(isoDate).getTime();
  const hrs = Math.floor(ms / 3600000);
  const mins = Math.floor(ms / 60000);
  if (mins < 60) return { label: `${mins}m at this stage`, color: "text-green-700 bg-green-50 border-green-200" };
  if (hrs < 12)  return { label: `${hrs}h at this stage`, color: "text-green-700 bg-green-50 border-green-200" };
  if (hrs < 24)  return { label: `${hrs}h at this stage`, color: "text-amber-700 bg-amber-50 border-amber-200" };
  if (hrs < 48)  return { label: `${hrs}h at this stage`, color: "text-amber-700 bg-amber-50 border-amber-200" };
  const days = Math.floor(hrs / 24);
  return { label: `${days}d ${hrs % 24}h at this stage`, color: "text-red-700 bg-red-50 border-red-200" };
}

function paymentStatusBadge(status: string | null | undefined) {
  if (!status) return null;
  const map: Record<string, { cls: string; icon: React.ReactNode; label: string }> = {
    paid:                 { cls: "bg-emerald-100 text-emerald-700 border-emerald-200", icon: <CheckCircle2 className="h-3 w-3" />, label: "Payment Secured" },
    paid_manual_verified: { cls: "bg-emerald-100 text-emerald-700 border-emerald-200", icon: <CheckCircle2 className="h-3 w-3" />, label: "Manually Verified" },
    override_approved:    { cls: "bg-amber-100 text-amber-700 border-amber-200",       icon: <ShieldCheck className="h-3 w-3" />,  label: "Override Approved" },
    requested:            { cls: "bg-blue-100 text-blue-700 border-blue-200",           icon: <CircleDollarSign className="h-3 w-3" />, label: "Payment Requested" },
    not_requested:        { cls: "bg-red-100 text-red-700 border-red-200",              icon: <Lock className="h-3 w-3" />,         label: "Payment Pending" },
    pending:              { cls: "bg-red-100 text-red-700 border-red-200",              icon: <Lock className="h-3 w-3" />,         label: "Payment Pending" },
    failed:               { cls: "bg-red-100 text-red-700 border-red-200",              icon: <AlertTriangle className="h-3 w-3" />, label: "Payment Failed" },
    refunded:             { cls: "bg-gray-100 text-gray-500 border-gray-200",           icon: null,                                  label: "Refunded" },
  };
  const entry = map[status] ?? { cls: "bg-gray-100 text-gray-500 border-gray-200", icon: null, label: status.replace(/_/g, " ") };
  return (
    <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded text-xs font-medium border ${entry.cls}`}
      data-testid="badge-payment-status">
      {entry.icon}
      {entry.label}
    </span>
  );
}

function statusBadge(status: string) {
  const map: Record<string, string> = {
    pending:       "bg-yellow-100 text-yellow-800 border-yellow-200",
    confirmed:     "bg-blue-100 text-blue-800 border-blue-200",
    in_progress:   "bg-purple-100 text-purple-800 border-purple-200",
    completed:     "bg-green-100 text-green-800 border-green-200",
    delivered:     "bg-green-100 text-green-800 border-green-200",
    cancelled:     "bg-red-100 text-red-800 border-red-200",
  };
  const cls = map[status] ?? "bg-gray-100 text-gray-700 border-gray-200";
  return (
    <Badge className={cls} data-testid="badge-order-status">
      {status.replace(/_/g, " ")}
    </Badge>
  );
}

export default function OpsOrderDetailPage() {
  const params  = useParams();
  const orderId = params.orderId as string;
  const supabase = createClient();
  const { toast } = useToast();

  const [order,      setOrder]      = useState<Order | null>(null);
  const [activities, setActivities] = useState<ActivityLogEntry[]>([]);
  const [profile,    setProfile]    = useState<Profile | null>(null);
  const [loading,    setLoading]    = useState(true);

  const [overridePackage, setOverridePackage] = useState("");
  const [overrideReason,  setOverrideReason]  = useState("");
  const [overrideLoading, setOverrideLoading] = useState(false);
  const [sendingPayment,  setSendingPayment]  = useState(false);

  // Payment override state
  const [paymentOverrideReason,    setPaymentOverrideReason]    = useState("");
  const [paymentOverrideConfirmed, setPaymentOverrideConfirmed] = useState(false);
  const [paymentOverrideLoading,   setPaymentOverrideLoading]   = useState(false);
  const [showPaymentOverrideCard,  setShowPaymentOverrideCard]  = useState(false);

  // Compensation panel scroll + highlight
  const [compensationHighlighted, setCompensationHighlighted] = useState(false);
  const handleNoPay = useCallback(() => {
    const el = document.getElementById("rc-compensation-panel");
    if (el) el.scrollIntoView({ behavior: "smooth", block: "center" });
    setCompensationHighlighted(true);
    setTimeout(() => setCompensationHighlighted(false), 3200);
  }, []);

  const loadData = useCallback(async () => {
    const { data: { session } } = await supabase.auth.getSession();
    if (!session) return;

    const [orderRes, activityRes, profileRes] = await Promise.all([
      supabase.from("orders").select("*").eq("id", orderId).single(),
      supabase
        .from("activity_log")
        .select("*")
        .eq("order_id", orderId)
        .order("created_at", { ascending: false }),
      supabase.from("profiles").select("*").eq("id", session.user.id).maybeSingle(),
    ]);

    if (orderRes.data)    setOrder(orderRes.data);
    if (activityRes.data) setActivities(activityRes.data);
    if (profileRes.data)  setProfile(profileRes.data);
    setLoading(false);
  }, [orderId]);

  // Initial load
  useEffect(() => { loadData(); }, [loadData]);

  // Auto-refresh every 45 s — surfaces RC acceptance / payment changes without manual reload
  useEffect(() => {
    const id = setInterval(loadData, 45_000);
    return () => clearInterval(id);
  }, [loadData]);

  /* ── Handlers ─────────────────────────────────────────────── */
  const handleStatusUpdate = async (newStatus: string) => {
    const res = await fetch(`/api/orders/${orderId}/status`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ status: newStatus }),
    });
    if (!res.ok) {
      const err = await res.json();
      toast({ title: "Error", description: err.error, variant: "destructive" });
      return;
    }
    toast({ title: "Status updated" });
    loadData();
  };

  const handleAssign = async (opsId: string) => {
    const res = await fetch(`/api/orders/${orderId}/assign`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ assigned_ops_id: opsId }),
    });
    if (!res.ok) {
      const err = await res.json();
      toast({ title: "Error", description: err.error, variant: "destructive" });
      return;
    }
    toast({ title: "Order assigned" });
    loadData();
  };

  const handleSendPayment = async () => {
    setSendingPayment(true);
    try {
      const res = await fetch(`/api/orders/${orderId}/send-payment`, { method: "POST" });
      if (!res.ok) {
        const err = await res.json();
        toast({ title: "Error", description: err.error, variant: "destructive" });
        return;
      }
      toast({ title: "Payment link sent" });
      loadData();
    } finally {
      setSendingPayment(false);
    }
  };

  const handlePaymentOverride = async () => {
    if (!paymentOverrideReason.trim() || paymentOverrideReason.trim().length < 5) {
      toast({ title: "Reason required", description: "Enter at least 5 characters.", variant: "destructive" });
      return;
    }
    if (!paymentOverrideConfirmed) {
      toast({ title: "Confirmation required", description: "Check the confirmation box first.", variant: "destructive" });
      return;
    }
    setPaymentOverrideLoading(true);
    try {
      const res = await fetch(`/api/admin/orders/${orderId}/payment-override`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ reason: paymentOverrideReason, confirmed: true }),
      });
      if (!res.ok) {
        const err = await res.json();
        toast({ title: "Override failed", description: err.error, variant: "destructive" });
        return;
      }
      toast({ title: "Payment override approved", description: "Field work is now unblocked for this order." });
      setPaymentOverrideReason("");
      setPaymentOverrideConfirmed(false);
      setShowPaymentOverrideCard(false);
      loadData();
    } finally {
      setPaymentOverrideLoading(false);
    }
  };

  const handlePackageOverride = async () => {
    if (!overridePackage) {
      toast({ title: "Select a package first", variant: "destructive" });
      return;
    }
    setOverrideLoading(true);
    const res = await fetch(`/api/ops/orders/${orderId}/package-override`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        package_override:        overridePackage,
        package_override_reason: overrideReason || null,
      }),
    });
    setOverrideLoading(false);
    if (!res.ok) {
      const err = await res.json();
      toast({ title: "Override failed", description: err.error, variant: "destructive" });
      return;
    }
    toast({ title: "Package overridden", description: `Set to ${packageLabel(overridePackage)}` });
    setOverridePackage("");
    setOverrideReason("");
    loadData();
  };

  /* ── Guards ───────────────────────────────────────────────── */
  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="animate-spin h-8 w-8 border-2 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  if (!order) {
    return (
      <div className="p-6">
        <p className="text-muted-foreground">Order not found.</p>
      </div>
    );
  }

  const role              = (profile?.role || "operations") as Role;
  const canOverride       = ["admin", "operations", "operations_lead", "owner"].includes(role);
  const canPaymentOverride = ["admin", "operations_lead", "ops_lead", "owner"].includes(profile?.role || "");
  const paymentAuthorized = canProceedWithRideCheck(order);
  const vehicle    = [order.vehicle_year, order.vehicle_make, order.vehicle_model]
    .filter(Boolean).join(" ");
  const buyerArrangedDetails = order as unknown as Record<string, unknown>;
  const inspectionAddress = typeof buyerArrangedDetails.inspection_address === "string"
    ? buyerArrangedDetails.inspection_address.trim()
    : "";
  const inspectionTimeWindow = typeof buyerArrangedDetails.inspection_time_window === "string"
    ? buyerArrangedDetails.inspection_time_window.trim()
    : "";
  const notesToInspector = typeof buyerArrangedDetails.notes_to_inspector === "string"
    ? buyerArrangedDetails.notes_to_inspector.trim()
    : "";
  const preferredLanguage = typeof buyerArrangedDetails.preferred_language === "string"
    ? buyerArrangedDetails.preferred_language.trim()
    : "";
  const hasBuyerArrangedDetails = Boolean(
    inspectionAddress || inspectionTimeWindow || notesToInspector || preferredLanguage,
  );

  const systemReason = order.classification_reason || "—";
  const isOverridden = systemReason.startsWith("[OPS OVERRIDE");

  /* ── Render ───────────────────────────────────────────────── */
  return (
    <div className="p-4 md:p-6 space-y-4 max-w-[1600px] mx-auto">
      {/* ── Top bar ─────────────────────────────────────────── */}
      <div className="flex items-start justify-between gap-4 flex-wrap">
        {/* Left: back + title */}
        <div className="flex items-center gap-3 min-w-0">
          <Link href="/operations/orders">
            <Button variant="ghost" size="sm" data-testid="button-back">
              <ArrowLeft className="h-4 w-4" />
            </Button>
          </Link>
          <div className="min-w-0">
            <div className="flex items-center gap-2 flex-wrap">
              <h1
                className="font-semibold text-lg leading-tight truncate"
                data-testid="heading-order-id"
              >
                {orderId.slice(0, 8).toUpperCase()}
              </h1>
              {statusBadge(order.status)}
              {order.ops_status && order.ops_status !== order.status && (
                <Badge variant="outline" className="text-xs">
                  {order.ops_status.replace(/_/g, " ")}
                </Badge>
              )}
              {(() => {
                const st = (order as unknown as Record<string, unknown>).seller_type as string | undefined;
                if (!st) return null;
                const config: Record<string, { cls: string; label: string }> = {
                  private_party: { cls: "bg-blue-100  text-blue-700  border-blue-200",  label: "👤 Private" },
                  dealership:    { cls: "bg-emerald-100 text-emerald-700 border-emerald-200", label: "🏢 Dealer" },
                  auction:       { cls: "bg-amber-100 text-amber-700  border-amber-200", label: "🔨 Auction" },
                  other:         { cls: "bg-gray-100  text-gray-600   border-gray-200",  label: "❓ Other"  },
                };
                const c = config[st] ?? config.other;
                return (
                  <span className={`inline-flex items-center text-xs font-medium border rounded px-1.5 py-0.5 ${c.cls}`} data-testid="badge-seller-type">
                    {c.label}
                  </span>
                );
              })()}
              {paymentStatusBadge(order.payment_status)}
              {(() => {
                const age = formatAge(order.updated_at);
                return age ? (
                  <span
                    className={`inline-flex items-center gap-1 text-xs font-medium border rounded px-1.5 py-0.5 ${age.color}`}
                    data-testid="badge-order-age"
                    title="Time since last status change"
                  >
                    <Clock className="h-3 w-3" />
                    {age.label}
                  </span>
                ) : null;
              })()}
            </div>
            {vehicle && (
              <p className="text-sm text-muted-foreground truncate">{vehicle}</p>
            )}
          </div>
        </div>

        {/* Right: actions */}
        <div className="flex items-center gap-2 flex-wrap shrink-0">
          {canUpdateStatus(role) && (
            <StatusUpdateDialog
              orderId={orderId}
              currentStatus={order.status}
              onUpdate={handleStatusUpdate}
            />
          )}
          {canAssignOps(role) && (
            <AssignOpsDialog
              orderId={orderId}
              currentOpsId={order.assigned_ops_id}
              onAssign={handleAssign}
            />
          )}
          {canSendPayment(role) &&
            order.booking_type === "concierge" &&
            order.payment_status === "not_requested" && (
              <Button
                variant="outline"
                size="sm"
                onClick={handleSendPayment}
                disabled={sendingPayment}
                data-testid="button-send-payment"
              >
                {sendingPayment ? (
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                ) : (
                  <Send className="h-4 w-4 mr-2" />
                )}
                Send Payment Link
              </Button>
            )}
        </div>
      </div>

      {/* ── SLA timing strip ────────────────────────────────── */}
      {(() => {
        const milestones: { label: string; ts: string | null | undefined; warnHrs: number; critHrs: number }[] = [
          { label: "Paid",            ts: order.paid_at,                  warnHrs: 4,  critHrs: 24  },
          { label: "Assigned",        ts: order.assigned_at,              warnHrs: 2,  critHrs: 8   },
          { label: "Seller confirmed",ts: order.seller_confirmed_at,      warnHrs: 4,  critHrs: 12  },
          { label: "Inspected",       ts: order.inspection_completed_at,  warnHrs: 4,  critHrs: 24  },
          { label: "Report delivered",ts: order.report_delivered_at ?? order.report_sent_at, warnHrs: 2, critHrs: 6 },
        ].filter((m) => m.ts);
        if (milestones.length === 0) return null;
        return (
          <div className="flex items-center gap-2 flex-wrap" data-testid="strip-sla">
            {milestones.map((m) => {
              const hrs = Math.floor((Date.now() - new Date(m.ts!).getTime()) / 3_600_000);
              const cls =
                hrs >= m.critHrs ? "text-red-700 bg-red-50 border-red-200 dark:bg-red-950/20 dark:text-red-400 dark:border-red-800" :
                hrs >= m.warnHrs ? "text-amber-700 bg-amber-50 border-amber-200 dark:bg-amber-950/20 dark:text-amber-400 dark:border-amber-800" :
                "text-green-700 bg-green-50 border-green-200 dark:bg-green-950/20 dark:text-green-400 dark:border-green-800";
              const display = hrs < 1
                ? `${Math.floor((Date.now() - new Date(m.ts!).getTime()) / 60_000)}m`
                : hrs < 24 ? `${hrs}h` : `${Math.floor(hrs / 24)}d`;
              return (
                <span key={m.label} className={`inline-flex items-center gap-1 text-xs font-medium border rounded-full px-2.5 py-0.5 ${cls}`}
                  data-testid={`sla-${m.label.replace(/\s/g, "-").toLowerCase()}`}>
                  <Clock className="h-3 w-3 shrink-0" />
                  {m.label}: <strong>{display} ago</strong>
                </span>
              );
            })}
          </div>
        );
      })()}

      {/* ── Payment gate banner ─────────────────────────────── */}
      {!paymentAuthorized && (
        <div className="flex items-start gap-3 rounded-lg border border-red-200 bg-red-50 dark:bg-red-950/20 dark:border-red-800 px-4 py-3"
          data-testid="banner-payment-gate">
          <Lock className="h-4 w-4 text-red-600 dark:text-red-400 mt-0.5 shrink-0" />
          <div className="flex-1 min-w-0">
            <p className="text-sm font-semibold text-red-700 dark:text-red-300">
              PENDING PAYMENT — NOT ACTIONABLE
            </p>
            <p className="text-xs text-red-600 dark:text-red-400 mt-0.5">
              Seller outreach, RideChecker assignment, dispatch, and inspection are blocked until payment is verified or an authorized Ops override is active.
              {order.payment_status === "override_approved"
                ? null
                : canPaymentOverride
                  ? " Use the Payment Override card below to unlock this order."
                  : " Contact your Ops Lead or Admin to approve a payment override."}
            </p>
          </div>
          {canPaymentOverride && !showPaymentOverrideCard && (
            <Button
              size="sm"
              variant="outline"
              className="shrink-0 text-xs border-red-300 text-red-700 hover:bg-red-100"
              onClick={() => setShowPaymentOverrideCard(true)}
              data-testid="button-open-payment-override"
            >
              <ShieldCheck className="h-3.5 w-3.5 mr-1" />
              Approve Override
            </Button>
          )}
        </div>
      )}

      {order.payment_status === "override_approved" && (
        <div className="flex items-center gap-3 rounded-lg border border-amber-200 bg-amber-50 dark:bg-amber-950/20 dark:border-amber-800 px-4 py-2.5"
          data-testid="banner-override-approved">
          <ShieldCheck className="h-4 w-4 text-amber-600 dark:text-amber-400 shrink-0" />
          <p className="text-sm text-amber-700 dark:text-amber-300">
            <span className="font-semibold">Payment Override Active</span>
            {order.payment_override_reason && (
              <span className="font-normal"> — {order.payment_override_reason}</span>
            )}
          </p>
        </div>
      )}

      {/* ── 2-column dashboard ──────────────────────────────── */}
      <div className="grid grid-cols-1 xl:grid-cols-[1fr_380px] gap-4 items-start">
        {/* ── LEFT column ─────────────────────────────────── */}
        <div className="space-y-4">
          <OrderDetailPanel order={order} activities={activities} />
          {hasBuyerArrangedDetails && (
            <Card data-testid="card-buyer-arranged-details">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm">Buyer-Arranged Inspection Details</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2 text-xs">
                {inspectionAddress && (
                  <div>
                    <p className="font-medium text-muted-foreground">Inspection address</p>
                    <p className="whitespace-pre-wrap">{inspectionAddress}</p>
                  </div>
                )}
                {inspectionTimeWindow && (
                  <div>
                    <p className="font-medium text-muted-foreground">Inspection time window</p>
                    <p>{inspectionTimeWindow}</p>
                  </div>
                )}
                {notesToInspector && (
                  <div>
                    <p className="font-medium text-muted-foreground">Notes to inspector</p>
                    <p className="whitespace-pre-wrap">{notesToInspector}</p>
                  </div>
                )}
                {preferredLanguage && (
                  <div>
                    <p className="font-medium text-muted-foreground">Preferred language</p>
                    <p>{preferredLanguage}</p>
                  </div>
                )}
              </CardContent>
            </Card>
          )}
          <SellerContactPanel order={order} onRefresh={loadData} paymentBlocked={!paymentAuthorized} />
          <CommunicationCenter order={order} onRefresh={loadData} />
        </div>

        {/* ── RIGHT column ───────────────────────────────── */}
        <div className="space-y-4">
          <BuyerCard order={order} onRefresh={loadData} />
          <RideCheckerCompensationPanel
            order={order}
            onRefresh={loadData}
            userRole={role}
            highlighted={compensationHighlighted}
          />
          <RideCheckerAssignmentPanel order={order} onRefresh={loadData} onNoPay={handleNoPay} paymentBlocked={!paymentAuthorized} />
          <JobStatusPanel order={order} onRefresh={loadData} />
          <PayPanel order={order} onRefresh={loadData} userRole={role} />
          <ReportPanel order={order} onRefresh={loadData} />
          <RiskFlagsPanel order={order} onRefresh={loadData} />
          <SellerRefusalAnalyticsCard order={order} />
          <TitleTransferCard orderId={orderId} sellerType={(order as unknown as Record<string, unknown>).seller_type as string | undefined} />
          <ConnecteamPanel order={order} onRefresh={loadData} />

          {/* Payment Override — ops_lead / admin / owner only */}
          {canPaymentOverride && showPaymentOverrideCard && !paymentAuthorized && (
            <Card className="border-red-200 dark:border-red-800" data-testid="card-payment-override">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm flex items-center gap-2 text-red-700 dark:text-red-400">
                  <ShieldCheck className="h-4 w-4" />
                  Approve Payment Override
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <p className="text-xs text-muted-foreground">
                  This unlocks seller outreach, RideChecker assignment, inspection, and report delivery
                  for an order where payment has not been collected. Use only in exceptional circumstances.
                </p>
                <div className="space-y-1">
                  <Label htmlFor="payment-override-reason" className="text-xs">Override reason <span className="text-red-500">*</span></Label>
                  <Textarea
                    id="payment-override-reason"
                    className="min-h-[64px] text-xs resize-none"
                    placeholder="e.g. Internal test, payment collected offline, pre-approved exception…"
                    value={paymentOverrideReason}
                    onChange={(e) => setPaymentOverrideReason(e.target.value)}
                    data-testid="textarea-payment-override-reason"
                  />
                </div>
                <div className="flex items-start gap-2">
                  <Checkbox
                    id="payment-override-confirm"
                    checked={paymentOverrideConfirmed}
                    onCheckedChange={(v) => setPaymentOverrideConfirmed(v === true)}
                    data-testid="checkbox-payment-override-confirm"
                    className="mt-0.5"
                  />
                  <Label htmlFor="payment-override-confirm" className="text-xs leading-snug cursor-pointer">
                    I understand this allows field work to proceed without confirmed payment
                    and that this action is logged for audit.
                  </Label>
                </div>
                <div className="flex gap-2">
                  <Button
                    size="sm"
                    variant="destructive"
                    className="flex-1 text-xs"
                    onClick={handlePaymentOverride}
                    disabled={paymentOverrideLoading || !paymentOverrideReason.trim() || !paymentOverrideConfirmed}
                    data-testid="button-confirm-payment-override"
                  >
                    {paymentOverrideLoading ? (
                      <><Loader2 className="h-3.5 w-3.5 mr-1.5 animate-spin" />Approving…</>
                    ) : (
                      "Approve Override"
                    )}
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    className="text-xs"
                    onClick={() => setShowPaymentOverrideCard(false)}
                    data-testid="button-cancel-payment-override"
                  >
                    Cancel
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Package Override */}
          {canOverride && (
            <Card data-testid="card-package-override">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm flex items-center gap-2">
                  <ShieldCheck className="h-4 w-4 text-primary" />
                  Package Override
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="text-xs text-muted-foreground space-y-0.5">
                  <p>
                    <span className="font-medium">Current: </span>
                    <span className="font-semibold">{packageLabel(order.package)}</span>
                    {order.base_price != null && (
                      <span className="ml-1">(${order.base_price})</span>
                    )}
                  </p>
                  <p>
                    <span className="font-medium">System reason: </span>
                    {isOverridden ? (
                      <span className="text-amber-600 dark:text-amber-400">{systemReason}</span>
                    ) : (
                      <span>{systemReason}</span>
                    )}
                  </p>
                </div>

                <div className="grid gap-2 sm:grid-cols-2">
                  <div className="space-y-1">
                    <Label htmlFor="override-pkg" className="text-xs">Force package to</Label>
                    <Select value={overridePackage} onValueChange={setOverridePackage}>
                      <SelectTrigger
                        id="override-pkg"
                        className="h-8 text-xs"
                        data-testid="select-override-package"
                      >
                        <SelectValue placeholder="Select…" />
                      </SelectTrigger>
                      <SelectContent>
                        {PACKAGE_OPTIONS.map((opt) => (
                          <SelectItem key={opt.value} value={opt.value} className="text-xs">
                            {opt.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-1">
                    <Label htmlFor="override-reason" className="text-xs">Reason (optional)</Label>
                    <Textarea
                      id="override-reason"
                      className="h-8 min-h-0 text-xs resize-none py-1.5"
                      placeholder="e.g. Confirmed EV, diesel, etc."
                      value={overrideReason}
                      onChange={(e) => setOverrideReason(e.target.value)}
                      data-testid="textarea-override-reason"
                    />
                  </div>
                </div>

                <Button
                  size="sm"
                  variant="outline"
                  onClick={handlePackageOverride}
                  disabled={overrideLoading || !overridePackage}
                  className="w-full"
                  data-testid="button-apply-override"
                >
                  {overrideLoading ? (
                    <><Loader2 className="h-3.5 w-3.5 mr-1.5 animate-spin" />Saving…</>
                  ) : (
                    "Apply Override"
                  )}
                </Button>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}
