"use client";

import { useState, useEffect, useCallback } from "react";
import type { Order, JobBroadcast } from "@/types/orders";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";
import {
  UserCheck,
  Radio,
  Loader2,
  Star,
  Briefcase,
  ChevronDown,
  X,
  CheckCircle2,
  Clock,
  XCircle,
  AlertTriangle,
  Send,
  Zap,
  Ban,
  Eye,
  EyeOff,
  Bell,
  MessageSquare,
  UserSquare2,
  ShieldOff,
} from "lucide-react";
import { RideCheckerProfileDrawer } from "@/components/ridecheckers/RideCheckerProfileDrawer";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { formatRelative } from "@/lib/utils/format";

interface RideCheckerSuggestion {
  id: string;
  full_name: string;
  email: string;
  phone: string | null;
  service_area: string | null;
  rc_city?: string | null;
  rc_state?: string | null;
  rc_zip?: string | null;
  service_radius_miles?: number | null;
  rating: number;
  ridechecker_score: number;
  active_jobs: number;
  max_daily_jobs: number;
  decline_count_30d: number;
  score: number;
  is_available: boolean;
  availability_updated_at: string | null;
  agreement_status?: string | null;
  current_agreement_version?: string | null;
  last_active_at?: string | null;
}

interface RideCheckerAssignmentPanelProps {
  order: Order;
  onRefresh: () => void;
  onNoPay?: () => void;
  paymentBlocked?: boolean;
}

function useCountdown(expiresAt: string | null | undefined, active: boolean) {
  const [secsLeft, setSecsLeft] = useState<number | null>(null);

  useEffect(() => {
    if (!expiresAt || !active) {
      setSecsLeft(null);
      return;
    }
    const tick = () => {
      const diff = Math.floor((new Date(expiresAt).getTime() - Date.now()) / 1000);
      setSecsLeft(Math.max(0, diff));
    };
    tick();
    const id = setInterval(tick, 1000);
    return () => clearInterval(id);
  }, [expiresAt, active]);

  return secsLeft;
}

function assignmentBadge(status: string | undefined) {
  switch (status) {
    case "awaiting_acceptance":
      return <Badge className="bg-amber-100 text-amber-800 border-amber-300 dark:bg-amber-950/40 dark:text-amber-300 dark:border-amber-700">Awaiting Acceptance</Badge>;
    case "assigned":
      return <Badge className="bg-blue-100 text-blue-800 border-blue-200">Assigned</Badge>;
    case "accepted":
      return <Badge className="bg-green-100 text-green-800 border-green-200">Accepted</Badge>;
    case "en_route":
      return <Badge className="bg-purple-100 text-purple-800 border-purple-200">En Route</Badge>;
    case "completed":
      return <Badge className="bg-green-100 text-green-800 border-green-200">Completed</Badge>;
    default:
      return <Badge variant="outline">Unassigned</Badge>;
  }
}

function broadcastStatusIcon(status: string) {
  switch (status) {
    case "accepted":
      return <CheckCircle2 className="h-3.5 w-3.5 text-green-600" />;
    case "declined":
      return <XCircle className="h-3.5 w-3.5 text-red-500" />;
    case "expired":
      return <AlertTriangle className="h-3.5 w-3.5 text-gray-400" />;
    default:
      return <Clock className="h-3.5 w-3.5 text-yellow-500" />;
  }
}

function broadcastStatusLabel(status: string) {
  switch (status) {
    case "accepted":  return "Accepted";
    case "declined":  return "Declined";
    case "expired":   return "Expired";
    default:          return "Sent";
  }
}

export function RideCheckerAssignmentPanel({ order, onRefresh, onNoPay, paymentBlocked = false }: RideCheckerAssignmentPanelProps) {
  const { toast } = useToast();

  const [ridecheckers, setRidecheckers] = useState<RideCheckerSuggestion[]>([]);
  const [rcLoading, setRcLoading] = useState(false);

  const [selectedDirect, setSelectedDirect] = useState<string>("");
  const [assigning, setAssigning] = useState(false);
  const [removing, setRemoving] = useState(false);
  const [cancelling, setCancelling] = useState(false);

  const [selectedBroadcast, setSelectedBroadcast] = useState<Set<string>>(new Set());
  const [broadcastPay, setBroadcastPay] = useState<string>(
    String(order.current_offer ?? order.base_pay ?? 0)
  );
  const [broadcasting, setBroadcasting] = useState(false);

  const [broadcasts, setBroadcasts] = useState<JobBroadcast[]>([]);
  const [bLoading, setBLoading] = useState(false);
  const [historyOpen, setHistoryOpen] = useState(false);

  // Expiry info for awaiting_acceptance — fetched from assignment
  const [assignmentExpiresAt, setAssignmentExpiresAt] = useState<string | null>(null);
  const [assignmentFirstViewed, setAssignmentFirstViewed] = useState<string | null>(null);
  const [assignmentLastNudge, setAssignmentLastNudge] = useState<string | null>(null);
  const [nudging, setNudging] = useState(false);
  const [nudgeCount, setNudgeCount] = useState(0);
  const [rcMsg, setRcMsg] = useState("");
  const [rcMsgSending, setRcMsgSending] = useState(false);
  const [rcMsgOpen, setRcMsgOpen] = useState(false);

  // RC profile drawer
  const [profileDrawerOpen, setProfileDrawerOpen] = useState(false);
  const [profileDrawerRcId, setProfileDrawerRcId] = useState<string | null>(null);

  // Broadcast eligibility filter (default: show eligible only)
  const [showAllRcs, setShowAllRcs] = useState(false);

  // Agreement reminder state — populated when an assign attempt is blocked by unsigned agreement
  const [agreementBlockedRc, setAgreementBlockedRc] = useState<RideCheckerSuggestion | null>(null);
  const [sendingReminder, setSendingReminder] = useState(false);
  const [reminderSent, setReminderSent] = useState(false);

  const isAwaitingAcceptance = order.assignment_status === "awaiting_acceptance";

  const secsLeft = useCountdown(assignmentExpiresAt, isAwaitingAcceptance);

  const loadRidecheckers = useCallback(async () => {
    setRcLoading(true);
    try {
      const res = await fetch("/api/admin/ridecheckers/suggest");
      if (res.ok) {
        const data = await res.json();
        setRidecheckers(data.suggestions ?? []);
      }
    } catch {
      /* silent */
    } finally {
      setRcLoading(false);
    }
  }, []);

  const loadBroadcasts = useCallback(async () => {
    setBLoading(true);
    try {
      const res = await fetch(`/api/ops/orders/${order.id}/broadcast`);
      if (res.ok) {
        const data = await res.json();
        setBroadcasts(data.broadcasts ?? []);
      }
    } catch {
      /* silent */
    } finally {
      setBLoading(false);
    }
  }, [order.id]);

  // Fetch latest assignment to get expires_at, first_viewed_at, last_nudge_at
  const loadAssignmentExpiry = useCallback(async () => {
    if (!order.assigned_ridechecker_id) return;
    try {
      const { createClient } = await import("@/lib/supabase/client");
      const supabase = createClient();
      const { data } = await supabase
        .from("ridechecker_job_assignments")
        .select("expires_at, status, first_viewed_at, last_nudge_at")
        .eq("order_id", order.id)
        .eq("ridechecker_id", order.assigned_ridechecker_id)
        .in("status", ["awaiting_acceptance", "assigned"])
        .order("created_at", { ascending: false })
        .limit(1)
        .maybeSingle();
      if (data?.expires_at) setAssignmentExpiresAt(data.expires_at);
      setAssignmentFirstViewed(data?.first_viewed_at ?? null);
      setAssignmentLastNudge(data?.last_nudge_at ?? null);

      // Count nudge events for this order
      const { count } = await supabase
        .from("order_events")
        .select("id", { count: "exact", head: true })
        .eq("order_id", order.id)
        .eq("event_type", "ridechecker_nudged");
      setNudgeCount(count ?? 0);
    } catch {
      /* silent */
    }
  }, [order.id, order.assigned_ridechecker_id]);

  useEffect(() => {
    loadRidecheckers();
    loadBroadcasts();
    if (isAwaitingAcceptance) {
      loadAssignmentExpiry();
    }
  }, [loadRidecheckers, loadBroadcasts, loadAssignmentExpiry, isAwaitingAcceptance]);

  async function handleDirectAssign() {
    if (!selectedDirect) return;
    setAssigning(true);
    try {
      const res = await fetch(`/api/ops/orders/${order.id}/ridechecker-assign`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ridechecker_id: selectedDirect }),
      });
      const data = await res.json();
      if (!res.ok) {
        const isNoPayError =
          res.status === 400 &&
          typeof data.error === "string" &&
          (data.error.toLowerCase().includes("pay rate must be set") ||
           data.error.toLowerCase().includes("compensation offer"));
        const isAgreementError =
          res.status === 400 &&
          typeof data.error === "string" &&
          data.error.toLowerCase().includes("contractor agreement");

        if (isNoPayError && onNoPay) {
          onNoPay();
          toast({
            title: "Compensation required",
            description: "Please calculate and save a RideChecker offer before assigning.",
            variant: "destructive",
          });
        } else if (isAgreementError) {
          const blockedRc = ridecheckers.find((r) => r.id === selectedDirect);
          setAgreementBlockedRc(blockedRc ?? null);
          setReminderSent(false);
        } else {
          toast({ title: "Assignment failed", description: data.error, variant: "destructive" });
        }
        return;
      }
      setAgreementBlockedRc(null);
      setReminderSent(false);
      const rc = ridecheckers.find((r) => r.id === selectedDirect);
      toast({
        title: "RideChecker notified",
        description: `${rc?.full_name} has 15 minutes to accept.`,
      });
      setSelectedDirect("");
      setAssignmentExpiresAt(data.expires_at ?? null);
      onRefresh();
      loadBroadcasts();
    } catch {
      toast({ title: "Unexpected error", variant: "destructive" });
    } finally {
      setAssigning(false);
    }
  }

  async function handleRemoveAssignment() {
    setRemoving(true);
    try {
      const res = await fetch(`/api/ops/orders/${order.id}/ridechecker-assign`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ridechecker_id: null }),
      });
      if (!res.ok) {
        toast({ title: "Failed to remove assignment", variant: "destructive" });
        return;
      }
      toast({ title: "Assignment removed" });
      setAssignmentExpiresAt(null);
      onRefresh();
    } catch {
      toast({ title: "Unexpected error", variant: "destructive" });
    } finally {
      setRemoving(false);
    }
  }

  async function handleSendRCMessage() {
    if (!rcMsg.trim()) return;
    setRcMsgSending(true);
    try {
      const res = await fetch(`/api/ops/orders/${order.id}/message-ridechecker`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: rcMsg.trim() }),
      });
      const data = await res.json();
      if (!res.ok) {
        toast({ title: "Failed to send", description: data.error, variant: "destructive" });
        return;
      }
      const sent: string[] = [];
      if (data.email) sent.push("email");
      if (data.sms) sent.push("SMS");
      toast({
        title: "Message sent to RideChecker",
        description: sent.length > 0 ? `Delivered via ${sent.join(" & ")}` : "Message dispatched.",
      });
      setRcMsg("");
      setRcMsgOpen(false);
    } catch {
      toast({ title: "Unexpected error", variant: "destructive" });
    } finally {
      setRcMsgSending(false);
    }
  }

  async function handleSendReminder() {
    if (!agreementBlockedRc) return;
    setSendingReminder(true);
    try {
      const res = await fetch(`/api/ops/orders/${order.id}/agreement-reminder`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ridechecker_id: agreementBlockedRc.id }),
      });
      const data = await res.json();
      if (!res.ok) {
        toast({ title: "Reminder failed", description: data.error, variant: "destructive" });
        return;
      }
      setReminderSent(true);
      toast({
        title: "Agreement reminder sent",
        description: `${agreementBlockedRc.full_name} was notified via ${(data.channels as string[]).join(" and ")}.`,
      });
    } catch {
      toast({ title: "Unexpected error", variant: "destructive" });
    } finally {
      setSendingReminder(false);
    }
  }

  async function handleNudge() {
    setNudging(true);
    try {
      const res = await fetch(`/api/ops/orders/${order.id}/nudge-ridechecker`, { method: "POST" });
      const data = await res.json();
      if (!res.ok) {
        toast({ title: "Nudge failed", description: data.error, variant: "destructive" });
        return;
      }
      const channels: string[] = [];
      if (data.sms_sent) channels.push("SMS");
      if (data.email_sent) channels.push("email");
      toast({
        title: "Reminder sent",
        description: channels.length > 0 ? `Sent via ${channels.join(" & ")}` : "Notification dispatched.",
      });
      setAssignmentLastNudge(new Date().toISOString());
    } catch {
      toast({ title: "Unexpected error", variant: "destructive" });
    } finally {
      setNudging(false);
    }
  }

  async function handleCancelAssignment() {
    setCancelling(true);
    try {
      const res = await fetch(`/api/ops/orders/${order.id}/cancel-assignment`, { method: "POST" });
      if (!res.ok) {
        toast({ title: "Failed to cancel assignment", variant: "destructive" });
        return;
      }
      toast({ title: "Assignment cancelled", description: "Order is now unassigned." });
      setAssignmentExpiresAt(null);
      onRefresh();
    } catch {
      toast({ title: "Unexpected error", variant: "destructive" });
    } finally {
      setCancelling(false);
    }
  }

  function toggleBroadcastSelect(id: string) {
    setSelectedBroadcast((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  }

  function toggleSelectAll() {
    if (selectedBroadcast.size === visibleRcs.length) {
      setSelectedBroadcast(new Set());
    } else {
      setSelectedBroadcast(new Set(visibleRcs.map((r) => r.id)));
    }
  }

  async function handleBroadcast() {
    if (selectedBroadcast.size === 0) {
      toast({ title: "Select at least one RideChecker", variant: "destructive" });
      return;
    }
    const pay = parseInt(broadcastPay, 10);
    if (isNaN(pay) || pay < 0) {
      toast({ title: "Enter a valid offered pay", variant: "destructive" });
      return;
    }
    setBroadcasting(true);
    try {
      const res = await fetch(`/api/ops/orders/${order.id}/broadcast`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ridechecker_ids: Array.from(selectedBroadcast),
          offered_pay: pay,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        toast({ title: "Broadcast failed", description: data.error, variant: "destructive" });
        return;
      }
      toast({
        title: "Broadcast sent!",
        description: `Notified ${data.sent_to} RideChecker${data.sent_to === 1 ? "" : "s"} ($${pay} offered)`,
      });
      setSelectedBroadcast(new Set());
      onRefresh();
      loadBroadcasts();
      setHistoryOpen(true);
    } catch {
      toast({ title: "Unexpected error", variant: "destructive" });
    } finally {
      setBroadcasting(false);
    }
  }

  const currentRc = order.assigned_ridechecker_id
    ? ridecheckers.find((r) => r.id === order.assigned_ridechecker_id)
    : null;

  // Eligibility helpers for the broadcast list
  function getBlockReason(rc: RideCheckerSuggestion): string | null {
    if ((rc as any).is_suspended) return "Suspended";
    if (rc.agreement_status !== "signed") return "Agreement not signed";
    if (rc.active_jobs >= rc.max_daily_jobs) return "At capacity";
    return null;
  }
  const isEligible = (rc: RideCheckerSuggestion) => getBlockReason(rc) === null;
  const eligibleCount = ridecheckers.filter(isEligible).length;
  const visibleRcs = showAllRcs ? ridecheckers : ridecheckers.filter(isEligible);

  const openBroadcasts = broadcasts.filter((b) => b.status === "sent");
  const hasHistory = broadcasts.length > 0;

  const minsLeft = secsLeft !== null ? Math.floor(secsLeft / 60) : null;
  const sLeft = secsLeft !== null ? secsLeft % 60 : null;
  const isExpiredCountdown = secsLeft !== null && secsLeft === 0;

  return (
    <div
      aria-disabled={paymentBlocked}
      inert={paymentBlocked || undefined}
      className={paymentBlocked ? "pointer-events-none opacity-70" : undefined}
    >
    <Card data-testid="card-ridechecker-assignment">
      <CardHeader className="pb-3">
        <CardTitle className="text-sm flex items-center justify-between gap-2">
          <span className="flex items-center gap-2">
            <UserCheck className="h-4 w-4 text-primary" />
            RideChecker Assignment
          </span>
          {assignmentBadge(order.assignment_status)}
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {paymentBlocked && (
          <div className="rounded-lg border border-amber-300 bg-amber-50 px-3 py-2 text-xs font-medium text-amber-900" data-testid="assignment-payment-lock">
            Pending payment — assignment and broadcast actions are disabled. Existing assignment history remains visible.
          </div>
        )}

        {/* ── Awaiting acceptance status pane ─────────────────── */}
        {isAwaitingAcceptance && order.assigned_ridechecker_id && (
          <div className={`rounded-lg border p-3 space-y-2 ${
            isExpiredCountdown
              ? "bg-red-50 border-red-200 dark:bg-red-950/20 dark:border-red-800"
              : "bg-amber-50 border-amber-200 dark:bg-amber-950/20 dark:border-amber-800"
          }`}>
            <div className="flex items-center gap-2">
              <Zap className={`h-4 w-4 flex-shrink-0 ${isExpiredCountdown ? "text-red-500" : "text-amber-600"}`} />
              <p className={`text-xs font-semibold ${isExpiredCountdown ? "text-red-700 dark:text-red-400" : "text-amber-800 dark:text-amber-300"}`}>
                {isExpiredCountdown ? "Acceptance window expired — reassign now" : "Awaiting RideChecker acceptance"}
              </p>
            </div>

            <div className="flex items-center gap-3 flex-wrap">
              <div className="flex-1 min-w-0">
                {currentRc ? (
                  <button
                    className="text-xs font-semibold text-left hover:underline flex items-center gap-1 text-foreground"
                    onClick={() => { setProfileDrawerRcId(currentRc.id); setProfileDrawerOpen(true); }}
                    data-testid="button-view-rc-profile-awaiting"
                  >
                    <UserSquare2 className="h-3 w-3 text-muted-foreground flex-shrink-0" />
                    {currentRc.full_name}
                  </button>
                ) : (
                  <p className="text-xs font-semibold truncate text-foreground">Assigned RideChecker</p>
                )}
                {currentRc?.email && (
                  <p className="text-xs text-muted-foreground truncate">{currentRc.email}</p>
                )}
              </div>
              {secsLeft !== null && !isExpiredCountdown && (
                <div
                  className={`inline-flex items-center gap-1.5 text-xs font-bold px-2.5 py-1 rounded-full ${
                    secsLeft < 180
                      ? "bg-red-100 text-red-700 dark:bg-red-900/40 dark:text-red-400"
                      : "bg-amber-100 text-amber-700 dark:bg-amber-900/40 dark:text-amber-300"
                  }`}
                  data-testid="text-ops-countdown"
                >
                  <Clock className="h-3 w-3" />
                  {minsLeft}m {sLeft! < 10 ? "0" : ""}{sLeft}s
                </div>
              )}
            </div>

            {/* Seen / Not opened indicator */}
            <div className="flex items-center gap-1.5 text-xs">
              {assignmentFirstViewed ? (
                <span className="flex items-center gap-1 text-green-700 dark:text-green-400 font-medium">
                  <Eye className="h-3 w-3" />
                  Opened {formatRelative(assignmentFirstViewed)}
                </span>
              ) : (
                <span className="flex items-center gap-1 text-muted-foreground">
                  <EyeOff className="h-3 w-3" />
                  Not yet opened
                </span>
              )}
              {assignmentLastNudge && (
                <span className="text-muted-foreground ml-2">
                  · Nudged {nudgeCount > 0 ? `${nudgeCount}×` : ""} {formatRelative(assignmentLastNudge)}
                </span>
              )}
            </div>

            <div className="flex gap-2 pt-1">
              <Button
                size="sm"
                variant="outline"
                className="h-7 text-xs flex-1 border-amber-300 hover:bg-amber-100 dark:border-amber-700 dark:hover:bg-amber-900/20"
                onClick={handleNudge}
                disabled={nudging || isExpiredCountdown}
                data-testid="button-nudge-ridechecker"
                title="Re-send SMS + email reminder to the RideChecker"
              >
                {nudging ? (
                  <Loader2 className="h-3 w-3 mr-1 animate-spin" />
                ) : (
                  <Bell className="h-3 w-3 mr-1" />
                )}
                Nudge
              </Button>
              <Button
                size="sm"
                variant="outline"
                className="h-7 text-xs flex-1 border-amber-300 hover:bg-amber-100 dark:border-amber-700 dark:hover:bg-amber-900/20"
                onClick={handleCancelAssignment}
                disabled={cancelling}
                data-testid="button-cancel-assignment"
              >
                {cancelling ? (
                  <Loader2 className="h-3 w-3 mr-1 animate-spin" />
                ) : (
                  <Ban className="h-3 w-3 mr-1" />
                )}
                Cancel &amp; Reassign
              </Button>
            </div>
          </div>
        )}

        {/* ── Accepted / active assignment ─────────────────────── */}
        {order.assigned_ridechecker_id && !isAwaitingAcceptance && (
          <div className="space-y-2">
            <div className="flex items-center justify-between gap-2 bg-muted/40 rounded-md px-3 py-2">
              <div className="min-w-0">
                {currentRc ? (
                  <button
                    className="text-xs font-medium text-left hover:underline flex items-center gap-1"
                    onClick={() => { setProfileDrawerRcId(currentRc.id); setProfileDrawerOpen(true); }}
                    data-testid="button-view-rc-profile-assigned"
                  >
                    <UserSquare2 className="h-3 w-3 text-muted-foreground flex-shrink-0" />
                    {currentRc.full_name}
                  </button>
                ) : (
                  <p className="text-xs font-medium truncate">Assigned RideChecker</p>
                )}
                {currentRc?.email && (
                  <p className="text-xs text-muted-foreground truncate">{currentRc.email}</p>
                )}
                {currentRc?.phone && (
                  <p className="text-xs text-muted-foreground truncate">{currentRc.phone}</p>
                )}
              </div>
              <Button
                variant="ghost"
                size="sm"
                className="h-7 px-2 text-muted-foreground hover:text-destructive shrink-0"
                onClick={handleRemoveAssignment}
                disabled={removing}
                data-testid="button-remove-assignment"
              >
                {removing ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <X className="h-3.5 w-3.5" />}
              </Button>
            </div>

            {/* Message RC */}
            {rcMsgOpen ? (
              <div className="rounded-md border bg-muted/30 p-2.5 space-y-2">
                <Textarea
                  value={rcMsg}
                  onChange={(e) => setRcMsg(e.target.value)}
                  placeholder="Type a message to the RideChecker…"
                  rows={3}
                  className="text-xs resize-none"
                  data-testid="textarea-rc-message"
                />
                <div className="flex gap-2">
                  <Button
                    size="sm"
                    className="h-7 text-xs flex-1 gap-1.5"
                    onClick={handleSendRCMessage}
                    disabled={rcMsgSending || !rcMsg.trim()}
                    data-testid="button-send-rc-message"
                  >
                    {rcMsgSending ? <Loader2 className="h-3 w-3 animate-spin" /> : <Send className="h-3 w-3" />}
                    Send
                  </Button>
                  <Button
                    size="sm"
                    variant="ghost"
                    className="h-7 text-xs"
                    onClick={() => { setRcMsgOpen(false); setRcMsg(""); }}
                    data-testid="button-cancel-rc-message"
                  >
                    Cancel
                  </Button>
                </div>
              </div>
            ) : (
              <Button
                size="sm"
                variant="outline"
                className="h-7 text-xs w-full gap-1.5"
                onClick={() => setRcMsgOpen(true)}
                data-testid="button-open-rc-message"
              >
                <MessageSquare className="h-3 w-3" />
                Message RideChecker
              </Button>
            )}
          </div>
        )}

        {/* ── Recall / Cancel — always visible when RC is assigned ── */}
        {order.assigned_ridechecker_id && (
          <div className="rounded-md border border-destructive/30 bg-destructive/5 p-3 space-y-1.5">
            <p className="text-xs font-semibold text-destructive">Recall Assignment</p>
            <p className="text-xs text-muted-foreground">
              Cancels this assignment and returns the order to unassigned. The RideChecker will be notified.
            </p>
            <Button
              size="sm"
              variant="destructive"
              className="h-7 text-xs w-full gap-1.5 mt-1"
              onClick={handleCancelAssignment}
              disabled={cancelling}
              data-testid="button-recall-assignment"
            >
              {cancelling ? (
                <Loader2 className="h-3 w-3 animate-spin" />
              ) : (
                <Ban className="h-3 w-3" />
              )}
              Recall &amp; Unassign
            </Button>
          </div>
        )}

        {/* ── Direct assign ───────────────────────────────────── */}
        <div className="space-y-2">
          <Label className="text-xs font-medium">
            {isAwaitingAcceptance ? "Reassign to Different RideChecker" : "Direct Assign"}
          </Label>
          <div className="flex gap-2">
            <Select
              value={selectedDirect}
              onValueChange={(v) => {
                setSelectedDirect(v);
                setAgreementBlockedRc(null);
                setReminderSent(false);
              }}
              disabled={rcLoading}
            >
              <SelectTrigger
                className="h-8 text-xs flex-1 min-w-0"
                data-testid="select-ridechecker-direct"
              >
                <SelectValue placeholder={rcLoading ? "Loading…" : "Pick a RideChecker"} />
              </SelectTrigger>
              <SelectContent>
                {ridecheckers.map((rc) => (
                  <SelectItem key={rc.id} value={rc.id} className="text-xs">
                    <span className="flex items-center gap-2">
                      <span className={`h-2 w-2 rounded-full flex-shrink-0 ${rc.is_available ? "bg-green-500" : "bg-gray-300"}`} />
                      <span className="font-medium">{rc.full_name}</span>
                      <span className="text-muted-foreground flex items-center gap-1">
                        <Star className="h-2.5 w-2.5" />
                        {rc.rating.toFixed(1)}
                      </span>
                      {rc.ridechecker_score > 0 && (
                        <span className="text-[10px] font-bold px-1 py-0 rounded bg-green-50 text-green-700 border border-green-200 leading-4">
                          {rc.ridechecker_score}pts
                        </span>
                      )}
                      <span className={`flex items-center gap-1 ${rc.active_jobs >= rc.max_daily_jobs ? "text-red-500" : "text-muted-foreground"}`}>
                        <Briefcase className="h-2.5 w-2.5" />
                        {rc.active_jobs}/{rc.max_daily_jobs}
                      </span>
                      {rc.decline_count_30d >= 3 && (
                        <span className="text-amber-600">⚠ {rc.decline_count_30d}d</span>
                      )}
                      {rc.agreement_status !== "signed" && (
                        <span className="text-red-600 font-bold">⚠ No Agreement</span>
                      )}
                    </span>
                  </SelectItem>
                ))}
                {!rcLoading && ridecheckers.length === 0 && (
                  <SelectItem value="__none__" disabled>No active RideCheckers</SelectItem>
                )}
              </SelectContent>
            </Select>
            <Button
              size="sm"
              className="h-8 shrink-0 gap-1.5"
              onClick={handleDirectAssign}
              disabled={assigning || !selectedDirect}
              data-testid="button-direct-assign"
            >
              {assigning ? (
                <Loader2 className="h-3.5 w-3.5 animate-spin" />
              ) : (
                <UserCheck className="h-3.5 w-3.5" />
              )}
              {isAwaitingAcceptance ? "Reassign" : "Assign"}
            </Button>
          </div>
          {selectedDirect && (() => {
            const selectedRc = ridecheckers.find((r) => r.id === selectedDirect);
            if (!selectedRc) return null;
            return (
              <div className="space-y-1.5">
                {!selectedRc.is_available && (
                  <div className="flex items-center gap-2 p-2 rounded-md bg-amber-50 border border-amber-200 dark:bg-amber-950/30 dark:border-amber-800">
                    <AlertTriangle className="h-3.5 w-3.5 text-amber-600 flex-shrink-0" />
                    <p className="text-xs text-amber-700 dark:text-amber-400">
                      <strong>{selectedRc.full_name}</strong> is currently marked unavailable. You can still assign them, but they may not respond promptly.
                    </p>
                  </div>
                )}
                {(selectedRc as any).agreement_status !== "signed" && (
                  agreementBlockedRc?.id === selectedRc.id ? (
                    <div className="rounded-md border border-amber-200 dark:border-amber-700 bg-amber-50 dark:bg-amber-950/30 p-3 space-y-2">
                      <div className="flex items-start gap-2">
                        <AlertTriangle className="h-4 w-4 text-amber-600 dark:text-amber-400 shrink-0 mt-0.5" />
                        <div className="min-w-0">
                          <p className="text-sm font-semibold text-amber-800 dark:text-amber-200">
                            Contractor agreement required
                          </p>
                          <p className="text-xs text-amber-700 dark:text-amber-300 mt-0.5">
                            {selectedRc.full_name} must sign the current contractor agreement before receiving assignments.
                          </p>
                        </div>
                      </div>
                      {reminderSent ? (
                        <div className="flex items-center gap-1.5 pl-6 text-xs text-green-700 dark:text-green-400">
                          <CheckCircle2 className="h-3.5 w-3.5 shrink-0" />
                          Reminder sent — waiting for {selectedRc.full_name} to sign.
                        </div>
                      ) : (
                        <Button
                          size="sm"
                          variant="outline"
                          className="ml-6 h-7 text-xs gap-1.5 border-amber-300 text-amber-800 hover:bg-amber-100 dark:border-amber-600 dark:text-amber-300 dark:hover:bg-amber-900/40"
                          onClick={handleSendReminder}
                          disabled={sendingReminder}
                          data-testid="button-send-agreement-reminder"
                        >
                          {sendingReminder
                            ? <Loader2 className="h-3 w-3 animate-spin" />
                            : <Bell className="h-3 w-3" />}
                          Send Agreement Reminder
                        </Button>
                      )}
                    </div>
                  ) : (
                    <div className="flex items-center gap-2 p-2 rounded-md bg-red-50 border border-red-200 dark:bg-red-950/30 dark:border-red-800">
                      <Ban className="h-3.5 w-3.5 text-red-600 flex-shrink-0" />
                      <p className="text-xs text-red-700 dark:text-red-400">
                        <strong>{selectedRc.full_name}</strong> has not signed the current contractor agreement. Assignment will be blocked.
                      </p>
                    </div>
                  )
                )}
              </div>
            );
          })()}
          <p className="text-xs text-muted-foreground">
            RideChecker will have 15 minutes to accept before the offer expires.
          </p>
        </div>

        <div className="relative">
          <div className="absolute inset-0 flex items-center">
            <span className="w-full border-t" />
          </div>
          <div className="relative flex justify-center text-xs uppercase">
            <span className="bg-card px-2 text-muted-foreground">or broadcast</span>
          </div>
        </div>

        {/* ── Broadcast ───────────────────────────────────────── */}
        <div className="space-y-3">
          <div className="flex items-center justify-between gap-2">
            <Label className="text-xs font-medium">Broadcast to RideCheckers</Label>
            <div className="flex items-center gap-2">
              <button
                onClick={() => setShowAllRcs((v) => !v)}
                className={`text-[10px] flex items-center gap-1 px-1.5 py-0.5 rounded border transition-colors ${
                  showAllRcs
                    ? "bg-amber-50 text-amber-700 border-amber-200 dark:bg-amber-950/20 dark:border-amber-700"
                    : "text-muted-foreground border-border hover:text-foreground"
                }`}
                data-testid="button-toggle-eligible-filter"
                title={showAllRcs ? "Showing all RideCheckers — click to show eligible only" : `Showing ${eligibleCount} eligible — click to show all`}
              >
                <ShieldOff className="h-3 w-3" />
                {showAllRcs ? `All (${ridecheckers.length})` : `Eligible (${eligibleCount})`}
              </button>
              {visibleRcs.length > 0 && (
                <button
                  onClick={toggleSelectAll}
                  className="text-xs text-primary hover:underline"
                  data-testid="button-select-all-broadcast"
                >
                  {selectedBroadcast.size === visibleRcs.length ? "Deselect all" : "Select all"}
                </button>
              )}
            </div>
          </div>

          <div className="max-h-48 overflow-y-auto rounded-md border divide-y">
            {rcLoading ? (
              <div className="flex items-center justify-center py-4">
                <Loader2 className="h-4 w-4 animate-spin text-muted-foreground" />
              </div>
            ) : ridecheckers.length === 0 ? (
              <p className="text-xs text-muted-foreground text-center py-3">No active RideCheckers</p>
            ) : visibleRcs.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-4 gap-1.5">
                <ShieldOff className="h-4 w-4 text-muted-foreground" />
                <p className="text-xs text-muted-foreground text-center">No eligible RideCheckers</p>
                <button onClick={() => setShowAllRcs(true)} className="text-xs text-primary hover:underline">
                  Show all ({ridecheckers.length})
                </button>
              </div>
            ) : (
              visibleRcs.map((rc) => {
                const blockReason = getBlockReason(rc);
                return (
                <div
                  key={rc.id}
                  className="flex items-start gap-3 px-3 py-2.5 hover:bg-muted/50"
                  data-testid={`item-broadcast-rc-${rc.id}`}
                >
                  <Checkbox
                    checked={selectedBroadcast.has(rc.id)}
                    onCheckedChange={() => toggleBroadcastSelect(rc.id)}
                    className="mt-0.5"
                    data-testid={`checkbox-broadcast-${rc.id}`}
                  />
                  <div className="flex-1 min-w-0 cursor-pointer" onClick={() => toggleBroadcastSelect(rc.id)}>
                    {/* Row 1: name + eligibility */}
                    <div className="flex items-center gap-1.5 flex-wrap">
                      <span
                        className={`h-2 w-2 rounded-full flex-shrink-0 ${rc.is_available ? "bg-green-500" : "bg-gray-300"}`}
                        title={rc.is_available ? "Available" : "Unavailable"}
                      />
                      <p className="text-xs font-semibold truncate">{rc.full_name}</p>
                      {!blockReason && (
                        <span className="text-[10px] font-semibold px-1 py-0 rounded bg-emerald-50 text-emerald-700 border border-emerald-200 leading-4">
                          Eligible ✓
                        </span>
                      )}
                      {blockReason && (
                        <span className="text-[10px] font-semibold px-1 py-0 rounded bg-amber-100 text-amber-700 border border-amber-200 leading-4">
                          {blockReason}
                        </span>
                      )}
                      {rc.decline_count_30d >= 4 && (
                        <span className="text-[10px] font-semibold px-1 py-0 rounded bg-red-100 text-red-700 border border-red-200 leading-4">
                          {rc.decline_count_30d} declines
                        </span>
                      )}
                    </div>
                    {/* Row 2: location */}
                    <p className="text-[11px] text-muted-foreground truncate mt-0.5">
                      {rc.rc_city && rc.rc_state
                        ? `${rc.rc_city}, ${rc.rc_state}${rc.service_radius_miles ? ` · ${rc.service_radius_miles} mi radius` : ""}`
                        : rc.service_area || rc.email}
                    </p>
                    {/* Row 3: jobs + last active */}
                    <div className="flex items-center gap-2 mt-0.5">
                      <span className={`text-[11px] flex items-center gap-0.5 ${rc.active_jobs >= rc.max_daily_jobs ? "text-red-500 font-medium" : "text-muted-foreground"}`}>
                        <Briefcase className="h-2.5 w-2.5" />
                        Jobs: {rc.active_jobs}/{rc.max_daily_jobs}
                      </span>
                      {rc.last_active_at && (
                        <span className="text-[11px] text-muted-foreground">
                          · Last active: {formatRelative(rc.last_active_at)}
                        </span>
                      )}
                      {!rc.last_active_at && (
                        <span className="text-[11px] text-muted-foreground/60">· No activity yet</span>
                      )}
                    </div>
                  </div>
                  <div className="flex flex-col items-end gap-1 shrink-0">
                    <div className="flex items-center gap-1 text-xs text-muted-foreground">
                      <Star className="h-2.5 w-2.5" />
                      {rc.rating.toFixed(1)}
                      {rc.ridechecker_score > 0 && (
                        <span className="text-[10px] font-bold px-1 py-0 rounded bg-green-50 text-green-700 border border-green-200 leading-4">
                          {rc.ridechecker_score}pts
                        </span>
                      )}
                    </div>
                    <button
                      className="p-0.5 rounded hover:bg-muted text-muted-foreground hover:text-foreground transition-colors"
                      onClick={(e) => { e.stopPropagation(); setProfileDrawerRcId(rc.id); setProfileDrawerOpen(true); }}
                      title={`View ${rc.full_name}'s profile`}
                      data-testid={`button-view-profile-${rc.id}`}
                    >
                      <UserSquare2 className="h-3.5 w-3.5" />
                    </button>
                  </div>
                </div>
                );
              })
            )}
          </div>

          <div className="flex gap-2 items-end">
            <div className="flex-1 space-y-1">
              <Label htmlFor="broadcast-pay" className="text-xs">Offered Pay ($)</Label>
              <Input
                id="broadcast-pay"
                type="number"
                min={0}
                value={broadcastPay}
                onChange={(e) => setBroadcastPay(e.target.value)}
                className="h-8 text-sm"
                data-testid="input-broadcast-pay"
              />
            </div>
            <Button
              size="sm"
              className="h-8 gap-1.5 shrink-0"
              onClick={handleBroadcast}
              disabled={broadcasting || selectedBroadcast.size === 0}
              data-testid="button-broadcast"
            >
              {broadcasting ? (
                <Loader2 className="h-3.5 w-3.5 animate-spin" />
              ) : (
                <Radio className="h-3.5 w-3.5" />
              )}
              Broadcast
              {selectedBroadcast.size > 0 && (
                <span className="ml-0.5 bg-white/20 rounded px-1 text-xs">
                  {selectedBroadcast.size}
                </span>
              )}
            </Button>
          </div>

          {openBroadcasts.length > 0 && (
            <div className="flex items-center gap-1.5 text-xs text-yellow-700 dark:text-yellow-400 bg-yellow-50 dark:bg-yellow-950/30 border border-yellow-200 dark:border-yellow-800 rounded px-2 py-1.5">
              <Send className="h-3.5 w-3.5 shrink-0" />
              <span>{openBroadcasts.length} pending broadcast{openBroadcasts.length > 1 ? "s" : ""} awaiting response</span>
            </div>
          )}
        </div>

        {/* ── Broadcast history ───────────────────────────────── */}
        {hasHistory && (
          <Collapsible open={historyOpen} onOpenChange={setHistoryOpen}>
            <CollapsibleTrigger asChild>
              <button
                className="flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground transition-colors w-full pt-1"
                data-testid="button-toggle-broadcast-history"
              >
                <ChevronDown
                  className={`h-3.5 w-3.5 transition-transform ${historyOpen ? "rotate-180" : ""}`}
                />
                Broadcast history ({broadcasts.length})
              </button>
            </CollapsibleTrigger>
            <CollapsibleContent className="mt-2">
              {bLoading ? (
                <div className="flex items-center justify-center py-3">
                  <Loader2 className="h-4 w-4 animate-spin text-muted-foreground" />
                </div>
              ) : (
                <div className="rounded-md border divide-y max-h-40 overflow-y-auto">
                  {broadcasts.map((b) => (
                    <div key={b.id} className="flex items-center gap-2 px-3 py-2">
                      {broadcastStatusIcon(b.status)}
                      <div className="flex-1 min-w-0">
                        <p className="text-xs font-medium truncate">
                          {b.ridechecker_name ?? b.ridechecker_id.slice(0, 8)}
                        </p>
                        <p className="text-xs text-muted-foreground">
                          {broadcastStatusLabel(b.status)} · ${b.offered_pay}
                        </p>
                      </div>
                      <span className="text-xs text-muted-foreground shrink-0">
                        {formatRelative(b.created_at)}
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </CollapsibleContent>
          </Collapsible>
        )}
      </CardContent>

      {/* ── RC Profile Drawer ── */}
      <RideCheckerProfileDrawer
        rcId={profileDrawerRcId}
        open={profileDrawerOpen}
        onOpenChange={setProfileDrawerOpen}
      />
    </Card>
    </div>
  );
}
